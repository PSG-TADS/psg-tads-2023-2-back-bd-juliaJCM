﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Sistema_Cobranca.Migrations
{
    /// <inheritdoc />
    public partial class Sistema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clientes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Senha = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Faturamentos",
                columns: table => new
                {
                    NumFaturamento = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Valor = table.Column<double>(type: "float", nullable: false),
                    MetodoPagamento = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cliente_id = table.Column<int>(type: "int", nullable: false),
                    cliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Faturamentos", x => x.NumFaturamento);
                    table.ForeignKey(
                     name: "FK_Faturamentos_Clientes_Cliente_id",
                     column: x => x.Cliente_id,
                     principalTable: "Clientes",
                     principalColumn: "Id",
                     onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Portas",
                columns: table => new
                {
                    Porta = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HoraSaida = table.Column<DateTime>(type: "datetime2", nullable: false),
                    HoraEntrada = table.Column<DateTime>(type: "datetime2", nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Portas", x => x.Porta);
                });

            migrationBuilder.CreateTable(
                name: "Tags",
                columns: table => new
                {
                    NumTag = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tags", x => x.NumTag);
                });

            migrationBuilder.CreateTable(
                name: "Veiculos",
                columns: table => new
                {
                    Placa = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Modelo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cliente_id = table.Column<int>(type: "int", nullable: false),
                    cliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tag_id = table.Column<int>(type: "int", nullable: false),
                    tag = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Veiculos", x => x.Placa);

                    table.ForeignKey(
                       name: "FK_Veiculos_Clientes_Cliente_id",
                       column: x => x.Cliente_id,
                       principalTable: "Clientes",
                       principalColumn: "Id",
                       onDelete: ReferentialAction.Cascade);

                    table.ForeignKey(
                       name: "FK_Veiculos_Tags_Tag_id",
                       column: x => x.Tag_id,
                       principalTable: "Tags",
                       principalColumn: "NumTag",
                       onDelete: ReferentialAction.Cascade);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clientes");

            migrationBuilder.DropTable(
                name: "Faturamentos");

            migrationBuilder.DropTable(
                name: "Portas");

            migrationBuilder.DropTable(
                name: "Tags");

            migrationBuilder.DropTable(
                name: "Veiculos");
        }
    }
}

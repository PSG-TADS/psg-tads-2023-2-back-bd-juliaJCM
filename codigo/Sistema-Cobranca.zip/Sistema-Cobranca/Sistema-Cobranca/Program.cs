﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sistema_Cobranca
{
    internal class Program
    {

        public class Cliente
        {
            [Key]
            public int Id { get; set; }
            public string? Nome { get; set; }
            public string? Email { get; set; }
            public int Senha { get; set; }
        }

        public class Veiculo
        {
            [Key]
            public string? Placa { get; set; }
            public string? Modelo { get; set; }
            public int Cliente_id { get; set; }
            [ForeignKey("Cliente_id")]
            public string? cliente { get; set; }
            public int Tag_id { get; set; }
            [ForeignKey("Tag_id")]
            public int tag { get; set; }
        }

        public class Tag
        {
            [Key]
            public int NumTag { get; set; }
        }

        public class PortaEntradaSaida
        {
            [Key]
            public int Porta { get; set; }
            public DateTime HoraSaida { get; set; }
            public DateTime HoraEntrada { get; set; }
        }

        public class Faturamento
        {
            [Key]
            public int NumFaturamento { get; set; }
            public double Valor { get; set; }
            public string? MetodoPagamento { get; set; }
            public int Cliente_id { get; set; }
            [ForeignKey("Cliente_id")]
            public string? cliente { get; set; }
        }

        public class ApplicationContext : DbContext
        {
            public DbSet<Cliente> Clientes { get; set; }
            public DbSet<Veiculo> Veiculos { get; set;}
            public DbSet<Tag> Tags { get; set; }
            public DbSet<PortaEntradaSaida> Portas { get; set; }
            public DbSet<Faturamento> Faturamentos { get; set; }

            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                _ = optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=SistemaEstacionamento;Trusted_Connection=True;TrustServerCertificate=true;");
            }
        }


        static void Main(string[] args)
        {

           using (var context = new ApplicationContext())
            {
                var client = new Cliente()
                {
                    Nome = "Fernanda",
                    Email = "nanda@gmail.com",
                    Senha = 6578
                };
                context.Clientes.Add(client);
                context.SaveChanges();

                var tag = new Tag()
                {

                };
                context.Tags.Add(tag);
                context.SaveChanges();

                var veiculo = new Veiculo()
                {
                    Placa = "FRRF",
                    Modelo = "Fiat Siena",
                    Cliente_id = client.Id,
                    Tag_id = tag.NumTag
                };
                context.Veiculos.Add(veiculo);
                context.SaveChanges();

                var porta = new PortaEntradaSaida()
                {
                    HoraEntrada = DateTime.Now,
                    HoraSaida = DateTime.Now.AddHours(2),
                };
                context.Portas.Add(porta);
                context.SaveChanges();

                var fat = new Faturamento()
                {
                    Valor = 10.0,
                    MetodoPagamento = "Dinheiro",
                    Cliente_id = client.Id
                };
                context.Faturamentos.Add(fat);
                context.SaveChanges();
            }
        }
    }
}
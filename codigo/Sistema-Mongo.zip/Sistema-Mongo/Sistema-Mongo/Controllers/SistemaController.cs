﻿using Sistema_Mongo.Services;
using Sistema_Mongo.Models;
using Microsoft.AspNetCore.Mvc;

namespace Sistema_Mongo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SistemaController : ControllerBase
    {
        private readonly SistemaServices _sistemaServices;
        public SistemaController(SistemaServices sistemaServices)
        {
            _sistemaServices = sistemaServices;
        }

        //GET TODOS
        [HttpGet]
        public async Task<List<Sistema>> Get() =>
            await _sistemaServices.GetAsync();

        //GET por ID 
        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<Sistema>> Get(string id)
        {
            var cliente = await _sistemaServices.GetAsync(id);
            if (cliente == null)
            {
                return NotFound();
            }
            return cliente;
        }

        //POST 
        [HttpPost]
        public async Task<IActionResult> Post(Sistema newSistema)
        {
            await _sistemaServices.CreateAsync(newSistema);

            return CreatedAtAction(nameof(Get), new { id = newSistema.Id }, newSistema);
        }

        //PUT 
        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update(string id, Sistema updatedSistema)
        {
            var cliente = await _sistemaServices.GetAsync(id);
            if (cliente is null)
                return NotFound();

            updatedSistema.Id = cliente.Id;
            await _sistemaServices.UpdateAsync(id, updatedSistema);
            return NoContent();
        }

        //DELETE 
        [HttpDelete("{id:length(24)}")]
        public async Task<IActionResult> Delete(string id)
        {
            var cliente = await _sistemaServices.GetAsync(id);
            if (cliente is null)
                return NotFound();

            await _sistemaServices.RemoveAsync(id);
            return NoContent();
        }
    }
}

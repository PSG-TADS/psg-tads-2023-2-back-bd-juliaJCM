﻿using Sistema_Mongo.Models;
using MongoDB.Driver;
using Microsoft.Extensions.Options;

namespace Sistema_Mongo.Services
{
    public class SistemaServices
    {
        private readonly IMongoCollection<Sistema> _sistemaCollection;
        public SistemaServices(
            IOptions<EstacionamentoDatabaseSettings> estacionamentoDatabaseSettings)
        {
            var mongoClient = new MongoClient(
                estacionamentoDatabaseSettings.Value.ConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(
                estacionamentoDatabaseSettings.Value.DatabaseName);
            _sistemaCollection = mongoDatabase.GetCollection<Sistema>(
                estacionamentoDatabaseSettings.Value.ClientesCollectionName);
        }
        //GET - RETORNA TODOS OS ITENS
        public async Task<List<Sistema>> GetAsync() => 
            await _sistemaCollection.Find(_=>true).ToListAsync();

        //GET - RETORNO UM ITEM ESPECÍFICO
        public async Task<Sistema?> GetAsync(string id) =>
          await _sistemaCollection.Find(x => x.Id == id).FirstOrDefaultAsync();

        //CREATE - CRIA UM NOVO ITEM
        public async Task CreateAsync(Sistema newSistema) =>
           await _sistemaCollection.InsertOneAsync(newSistema);
    
        //UPDATE - ATUALIZA UM ITEM
        public async Task UpdateAsync(string id, Sistema updatedSistema) =>
           await _sistemaCollection.ReplaceOneAsync(x => x.Id == id, updatedSistema);

        //REMOVE - REMOVE UM ITEM
        public async Task RemoveAsync(string id) =>
            await _sistemaCollection.DeleteOneAsync(x => x.Id == id);
    }
}
